import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get settings => 'Settings';

  @override
  String get name => 'Sanskar';

  @override
  String get general_settings => 'General Settings';

  @override
  String get general => 'General';

  @override
  String get privacy_Security => 'Privacy & Security';

  @override
  String get language => 'Language';

  @override
  String get share_app => 'Share App';

  @override
  String get display_theme => 'Display & Theme';

  @override
  String get dark_mode => 'Dark Mode';

  @override
  String get account => 'Account';

  @override
  String get logout => 'Logout';

  @override
  String get delete_account => 'Delete Account';

  @override
  String get change_password => 'Change Password';

  @override
  String get feedback => 'Feedback';

  @override
  String get send_feedback => 'Send Feedback';

  @override
  String get contact_us => 'Contact Us';

  @override
  String get about => 'About';
}
