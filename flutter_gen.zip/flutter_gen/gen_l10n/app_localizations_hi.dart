import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Hindi (`hi`).
class AppLocalizationsHi extends AppLocalizations {
  AppLocalizationsHi([String locale = 'hi']) : super(locale);

  @override
  String get settings => 'सेटिंग्स';

  @override
  String get name => 'संस्कार';

  @override
  String get general_settings => 'सामान्य सेटिंग्स';

  @override
  String get general => 'सामान्य';

  @override
  String get privacy_Security => 'निजता एवं सुरक्षा';

  @override
  String get language => 'भाषा';

  @override
  String get share_app => 'ऐप साझा करें';

  @override
  String get display_theme => 'थीम प्रदर्शित करें';

  @override
  String get dark_mode => 'डार्क मोड';

  @override
  String get account => 'खाता';

  @override
  String get logout => 'लॉग आउट';

  @override
  String get delete_account => 'खाता हटा दो';

  @override
  String get change_password => 'पासवर्ड बदलें';

  @override
  String get feedback => 'प्रतिक्रिया';

  @override
  String get send_feedback => 'प्रतिक्रिया भेजें';

  @override
  String get contact_us => 'हमसे संपर्क करें';

  @override
  String get about => 'ऐप के बारे में';
}
